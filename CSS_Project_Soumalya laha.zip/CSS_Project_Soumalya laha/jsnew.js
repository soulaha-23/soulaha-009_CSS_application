var model ="hp"
var color ="blacklgray"
var ram = "4GB"
var rom = "1TB"
console.log(ram,model,color,rom)

var model ="Redmi"
var color =  "blue"
var ram = "4GB"
var rom = "128GB"
var price = "12k"
console.log(ram,model,color,rom,price)

var branch ="Kolkata"
var name ="soumalya laha"
var course = "Development"
console.log(branch,course,name)

var brand ="Khadim"
var color ="blaclgray"
var price = "1000"
console.log(price,brand,color)

